package com.category.test.service;

import java.util.List;

import com.category.test.entitiy.Category;

public interface CategoryService {
	// insert
	public Category insert(Category vo) throws Exception;

	// viewall
	public List<Category> viewall() throws Exception;
	
	// update
	public Category update(Category vo) throws Exception;
	
	// rowlist
	public List<Category> rowlist(Category vo) throws Exception;
}
