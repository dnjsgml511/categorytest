package com.category.test.controller;

import javax.annotation.Resource;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.category.test.entitiy.Category;
import com.category.test.service.CategoryService;

@RestController
public class CategoryController {

	@Resource
	CategoryService service;

	// save
	@GetMapping(value = "/insert")
	public ResponseEntity<?> insert(@RequestBody Category vo) throws Exception {
		return new ResponseEntity<>(service.insert(vo), HttpStatus.OK);
	}

	// viewall
	@GetMapping(value = "/viewall")
	public ResponseEntity<?> viewall() throws Exception {
		return new ResponseEntity<>(service.viewall(), HttpStatus.OK);
	}

	// update
	@GetMapping(value = "/update")
	public ResponseEntity<?> update(@RequestBody Category vo) throws Exception {
		return new ResponseEntity<>(service.update(vo), HttpStatus.OK);
	}
	
	// row list
	@GetMapping(value ="/rowlist")
	public ResponseEntity<?> rowlist(@RequestBody Category vo) throws Exception{
		return new ResponseEntity<>(service.rowlist(vo), HttpStatus.OK);
	}
}
