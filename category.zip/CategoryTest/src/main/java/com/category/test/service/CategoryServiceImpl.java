package com.category.test.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.category.test.entitiy.Category;
import com.category.test.repository.CategoryRepository;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	CategoryRepository repository;

	@Override
	public Category insert(Category vo) throws Exception {

		List<Category> isParent = repository.findByIdx(vo.getParent());
		if (vo.getParent() == 0) {
			if (isParent.size() == 0) {
				vo.setRownums(1);
			} else {
				vo.setRownums(isParent.getRownums() + 1);
			}
			return repository.save(vo);
		} else {
			if (isParent.isPresent()) {
				return null;
			} else {
				List<Category> brothers = repository.findByParent(vo.getParent());
				System.out.println(brothers);
			}
		}
		return null;
	}

	@Override
	public List<Category> viewall() throws Exception {
		return repository.findAll();
	}

	@Override
	public Category update(Category vo) throws Exception {
		Optional<Category> update = repository.findById(vo.getIdx());
		if (update.isPresent()) {
			Category newvo = update.get();

			if (!vo.getCategory().equals(""))
				newvo.setCategory(vo.getCategory()); // 카테고리
			if (!(vo.getParent() == 0))
				newvo.setParent(vo.getParent()); // 부모
			if (!(vo.getRownums() == 0))
				newvo.setRownums(vo.getRownums()); // rownum

			return repository.save(newvo);
		}
		return null;
	}

	@Override
	public List<Category> rowlist(Category vo) throws Exception {
		return null;
	}

}
