package com.category.test.entitiy;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Category {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idx;
	private String category;
	private int parent;
	private int rownums;
	
	public Category() {
		this.category = "";
	}
}
